
import torch
import numpy as np
import cv2
import matplotlib.pyplot as plt
from PIL import Image
from torchvision import transforms
from skimage import morphology
import matplotlib.animation as animation
from mpl_toolkits.mplot3d import Axes3D

# Load MiDaS Model
def load_midas_model():
    model = torch.hub.load("isl-org/MiDaS", "MiDaS_small")  # Using lightweight model
    model.eval()
    return model

# Preprocess Image for MiDaS
def preprocess_image(image_path):
    image = Image.open(image_path).convert("RGB")
    
    transform = transforms.Compose([
        transforms.Resize((384, 384)),  # Resize to MiDaS input size
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    image_tensor = transform(image).unsqueeze(0)  # Add batch dimension (N, C, H, W)
    
    return image_tensor, np.array(image)  # Return original image for visualization

# Predict Depth Map
def estimate_depth(model, image_tensor):
    with torch.no_grad():
        depth = model(image_tensor)  # Get depth output from model
        # Ensure correct format for interpolation
        if depth.dim() == 3:  
            depth = depth.unsqueeze(1)  # Convert to (1, 1, H, W)
        
        depth = torch.nn.functional.interpolate(
            depth, size=(image_tensor.shape[2], image_tensor.shape[3]), mode="bilinear", align_corners=False
        )
    return depth.squeeze().cpu().numpy()

# Extract bones from CT scan based on intensity thresholding
def extract_bone_from_ct(image):
    """
    Extract bone from CT scan image based on typical HU (Hounsfield Unit) value ranges.
    For CT scans, bones typically appear white (high intensity).
    """
    # Convert to grayscale if it's not already
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    else:
        gray = image
    
    # Apply histogram equalization to enhance contrast
    equalized = cv2.equalizeHist(gray)
    
    # Use Otsu's thresholding to automatically determine threshold for bone
    _, binary_bones = cv2.threshold(equalized, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # Apply morphological operations to clean up noise
    kernel = np.ones((3, 3), np.uint8)
    binary_bones = cv2.morphologyEx(binary_bones, cv2.MORPH_CLOSE, kernel)
    binary_bones = cv2.morphologyEx(binary_bones, cv2.MORPH_OPEN, kernel)
    
    # Remove small objects (likely noise)
    binary_bones = morphology.remove_small_objects(binary_bones.astype(bool), min_size=100)
    bone_mask = (binary_bones * 255).astype(np.uint8)
    
    # Apply mask to original image to get only bone structure
    if len(image.shape) == 3:
        bone_structure = cv2.bitwise_and(image, image, mask=bone_mask)
    else:
        bone_structure = cv2.bitwise_and(image, image, mask=bone_mask)
        bone_structure = cv2.cvtColor(bone_structure, cv2.COLOR_GRAY2RGB)
    
    return bone_structure, bone_mask

# Create 3D representation of bone structure without graph-based skeleton
def create_3d_bone_representation(depth_map, bone_mask, original_image):
    """
    Create 3D representation of bone structure using depth information
    """
    # Resize masks to match depth map dimensions
    h, w = depth_map.shape
    bone_mask_resized = cv2.resize(bone_mask, (w, h))
    
    # Combine depth and bone mask
    bone_depth = depth_map * (bone_mask_resized > 0)
    
    # Further enhance the bone structures by thresholding the depth
    depth_min = np.min(bone_depth[bone_depth > 0]) if np.any(bone_depth > 0) else 0
    depth_max = np.max(bone_depth)
    normalized_depth = (bone_depth - depth_min) / (depth_max - depth_min + 1e-6)
    
    # Get all points from the bone mask for point cloud
    x, y = np.meshgrid(np.arange(w), np.arange(h))
    x = x[bone_mask_resized > 0]
    y = y[bone_mask_resized > 0]
    z = normalized_depth[bone_mask_resized > 0]
    
    # Get colors from the original image
    original_resized = cv2.resize(original_image, (w, h))
    if len(original_image.shape) == 3:
        r = original_resized[..., 0][bone_mask_resized > 0] / 255
        g = original_resized[..., 1][bone_mask_resized > 0] / 255
        b = original_resized[..., 2][bone_mask_resized > 0] / 255
        colors = np.column_stack((r, g, b))
    else:
        intensity = original_resized[bone_mask_resized > 0] / 255
        colors = np.column_stack((intensity, intensity, intensity))
    
    return x, y, z, colors

# Create rotating animation of the 3D bone structure without graph skeleton
def create_rotating_bone_animation(x, y, z, colors, output_path="rotating_bone.gif"):
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    # Initial scatter plot for point cloud
    scatter = ax.scatter(x, y, z, c=colors, s=2, alpha=0.7)
    
    # Set axis limits for better visualization
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('3D Bone Structure')
    
    # Remove background and grids for better visualization
    ax.xaxis.pane.fill = False
    ax.yaxis.pane.fill = False
    ax.zaxis.pane.fill = False
    ax.grid(False)
    
    # Set viewing angle for better perception of depth
    ax.view_init(elev=30, azim=0)
    
    # Function to update the plot for each animation frame
    def update(frame):
        ax.view_init(elev=30, azim=frame)
        return scatter,
    
    # Create animation with 360-degree rotation
    # Use fewer frames for GIF to keep file size manageable
    anim = animation.FuncAnimation(fig, update, frames=np.arange(0, 360, 10), interval=100, blit=True)
    
    # Save the animation as GIF
    # Make sure output_path ends with .gif
    if not output_path.endswith('.gif'):
        output_path = output_path.split('.')[0] + '.gif'
    
    print(f"Saving animation to {output_path}...")
    anim.save(output_path, writer='pillow', fps=10)
    plt.close(fig)
    
    print(f"Animation saved to {output_path}")
    return output_path

# Main Function to convert 2D CT bone image to rotating 3D visualization (without graph)
def convert_ct_bone_to_3d(image_path, output_path="rotating_bone.gif", bone_color=None):
    """
    Convert a CT scan image to a 3D bone model without skeleton graph.
    
    Parameters:
    - image_path: Path to the CT scan image
    - output_path: Path to save the rotating 3D visualization
    - bone_color: If specified, extract bones of this color range [lower_hsv, upper_hsv]
                 e.g., bone_color=[[0, 0, 200], [180, 30, 255]] for white/bright bones
    """
    # Load model and process image
    model = load_midas_model()
    image_tensor, original_image = preprocess_image(image_path)
    
    # Estimate depth
    print("Estimating depth map...")
    depth_map = estimate_depth(model, image_tensor)
    
    # Extract bone structure
    print("Extracting bone structure...")
    if bone_color:
        # Extract bone by specific color range if provided
        lower_color, upper_color = bone_color
        # Convert to HSV color space for better color segmentation
        hsv = cv2.cvtColor(original_image, cv2.COLOR_RGB2HSV)
        
        # Create a mask for the specified color range
        bone_mask = cv2.inRange(hsv, np.array(lower_color), np.array(upper_color))
        
        # Apply morphological operations to clean up the mask
        kernel = np.ones((3, 3), np.uint8)
        bone_mask = cv2.morphologyEx(bone_mask, cv2.MORPH_CLOSE, kernel)
        bone_mask = cv2.morphologyEx(bone_mask, cv2.MORPH_OPEN, kernel)
        
        # Apply the mask to get only the bone structure
        bone_structure = cv2.bitwise_and(original_image, original_image, mask=bone_mask)
    else:
        # Use standard CT bone extraction
        bone_structure, bone_mask = extract_bone_from_ct(original_image)
    
    # Create 3D representation without graph
    print("Creating 3D representation of bone structure...")
    x, y, z, colors = create_3d_bone_representation(
        depth_map, bone_mask, original_image
    )
    
    # Check if we have enough points for 3D visualization
    if len(x) < 100:
        print("Warning: Not enough bone structure detected. Adjusting extraction parameters...")
        # Try with more lenient thresholding
        bone_structure, bone_mask = extract_bone_from_ct(original_image)
        x, y, z, colors = create_3d_bone_representation(
            depth_map, bone_mask, original_image
        )
    
    # Create and save the rotating animation
    print("Creating rotating animation...")
    animation_path = create_rotating_bone_animation(
        x, y, z, colors, output_path
    )
    
    # Display bone structure and depth map
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.imshow(cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB))
    plt.title("Original CT Scan")
    plt.axis("off")
    
    plt.subplot(1, 3, 2)
    plt.imshow(cv2.cvtColor(bone_structure, cv2.COLOR_BGR2RGB))
    plt.title("Extracted Bone Structure")
    plt.axis("off")
    
    plt.subplot(1, 3, 3)
    plt.imshow(depth_map, cmap='plasma')
    plt.title("Depth Map")
    plt.axis("off")
    
    plt.tight_layout()
    plt.savefig(output_path.split('.')[0] + "_processing.png")
    plt.show()
    
    print(f"Processing complete! The rotating 3D bone visualization has been saved to {animation_path}")
    
    return animation_path

# Example Usage
if __name__ == "__main__":
    image_path = "clearbone.png"  # Replace with your CT scan image path
    output_path = "rotating_bone.gif"  # Output GIF file
    
    # For white/bright bones in CT scan (common in most CT visualizations)
    # Format: [lower_bound_hsv, upper_bound_hsv]
    white_bone_color = [[0, 0, 180], [180, 30, 255]]  # HSV range for white/bright areas
    
    # Run the conversion without graph-based skeleton
    convert_ct_bone_to_3d(
        image_path, 
        output_path,
        bone_color=white_bone_color  # Specify color range for bone extraction
    )